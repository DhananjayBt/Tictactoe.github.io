
import './App.css';
import Board from './Components/Board';
//import Square from './Components/Square';

function App() {
  return (
    <>
  <Board /> 
 {/* <Square />*/}
 </>
  );
}

export default App;
